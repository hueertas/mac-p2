//
//  QuizCell.swift
//  Practica4-Quiz10
//
//  Created by g939 DIT UPM on 21/11/2019.
//  Copyright © 2019 IWEB. All rights reserved.
//

import UIKit

class QuizCell: UITableViewCell {


    @IBOutlet weak var authorLabel: UILabel!
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var qLabel: UILabel!
    
}


